import useSocket from '@/hooks/useSocket';

const SocketInitializer = () => {
    useSocket();
    return null;
};

export default SocketInitializer;
